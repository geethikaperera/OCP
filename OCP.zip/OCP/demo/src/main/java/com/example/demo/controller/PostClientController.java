package com.example.demo.controller;

import java.util.List;
import java.util.Map;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.example.demo.model.Order;
import com.example.demo.model.Response;
import com.example.demo.model.Returns;
import com.example.demo.service.ReadCSVService;
import com.example.demo.util.LoggerUtil;

@Controller
public class PostClientController {

	private static final Logger LOGGER = LoggerFactory.getLogger(PostClientController.class);
	
	@Autowired
	private ReadCSVService readCSVService;
	
	@PostMapping("/upload")
	public void read(@RequestParam("file") MultipartFile file) throws Exception{
		readCSVService.read();
	}

	@PostMapping("/post-order")
	public ResponseEntity<Response> postOrder(@RequestBody Returns jsonReq)throws Exception{
		
		String requestString = LoggerUtil.convertToString(jsonReq);
		LOGGER.info("postOrderRequest : Order={}", requestString);
		
		CloseableHttpClient client = HttpClients.createDefault();
	    HttpPost httpPost = new HttpPost("https://stg.stevemadden.com/services/wmi/shipment/return.do");

	    String json = "{\"OrderId\": \"SMUS#376568122225\",\r\n"
	    		+ "        \"Order\": {\r\n"
	    		+ "            \"SiteCode\": \"SM\"\r\n"
	    		+ "        },\r\n"
	    		+ "        \"Items\": [\r\n"
	    		+ "            {\r\n"
	    		+ "                \"ItemIndex\": 13508235,\r\n"
	    		+ "                \"Confirm\": \"Y\",\r\n"
	    		+ "                \"ItemCondition\": \"NEW\",\r\n"
	    		+ "                \"StoreNo\": 906,\r\n"
	    		+ "                \"IsExchange\": \"Y\"\r\n"
	    		+ "            }\r\n"
	    		+ "        ]}";
	    
	    StringEntity entity = new StringEntity(json);
	    httpPost.setEntity(entity);
	    httpPost.setHeader("Accept", "application/json");
	    httpPost.setHeader("Content-type", "application/json");
		
	    CloseableHttpResponse response = client.execute(httpPost);
		String responseString = LoggerUtil.convertToString(response);
		LOGGER.info("postOrderResponse : Order={}", responseString);
	    client.close();
	    return ResponseEntity.ok().body(new Response());
	}
}
