package com.example.demo.model;

public class Order {

	private String orderId = "SMUS#376568122225";
	
	private final static String siteCode = "SM";
	
	private String itemIndex = "13508235";
	
	private  final static String confirm = "Y";
	
	private final static String ItemCondition = "NEW";
	
	private final static String storeNo = "906";
	
	private String isExchange = "Y";

	public Order(String orderId, String itemIndex, String isExchange) {
		super();
		this.orderId = orderId;
		this.itemIndex = itemIndex;
		this.isExchange = isExchange;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getItemIndex() {
		return itemIndex;
	}

	public void setItemIndex(String itemIndex) {
		this.itemIndex = itemIndex;
	}


	public String getIsExchange() {
		return isExchange;
	}

	public void setIsExchange(String isExchange) {
		this.isExchange = isExchange;
	}

	public String getSiteCode() {
		return siteCode;
	}

	public String getItemCondition() {
		return ItemCondition;
	}

	public String getStoreno() {
		return storeNo;
	}	

	public String getConfirm() {
		return confirm;
	}

	@Override
	public String toString() {
		return "Order [orderId=" + orderId + ", siteCode=" + siteCode + ", itemIndex=" + itemIndex + ", confirm="
				+ confirm + ", ItemCondition=" + ItemCondition + ", isExchange=" + isExchange + "]";
	}

}
