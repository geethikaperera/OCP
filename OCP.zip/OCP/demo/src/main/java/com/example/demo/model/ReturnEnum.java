package com.example.demo.model;

public enum ReturnEnum {
	
	siteCode("SM"),
	confirm("Y"),
	itemCondition("NEW"),
	storeNo("906");
	
	private String code;

	private ReturnEnum(String code) {
		this.code = code;
	}

	public String getEnum() {
		return code;
	}
}
