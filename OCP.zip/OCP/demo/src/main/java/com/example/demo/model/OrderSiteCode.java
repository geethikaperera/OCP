package com.example.demo.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class OrderSiteCode {

	@JsonProperty("SiteCode")
	private String SiteCode;

	public String getSiteCode() {
		return SiteCode;
	}

	public void setSiteCode(String siteCode) {
		SiteCode = siteCode;
	}
	
}
