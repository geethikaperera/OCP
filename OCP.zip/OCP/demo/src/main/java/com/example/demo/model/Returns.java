package com.example.demo.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Returns {

	@JsonProperty("OrderId")
	private String orderId;
	
	@JsonProperty("Order")
	private List<OrderSiteCode> orders;

	@JsonProperty("Items")
	private List<ItemsObject> Items;

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public List<OrderSiteCode> getOrders() {
		return orders;
	}

	public void setOrders(List<OrderSiteCode> orders) {
		this.orders = orders;
	}

	public List<ItemsObject> getItems() {
		return Items;
	}

	public void setItems(List<ItemsObject> items) {
		Items = items;
	}

}
