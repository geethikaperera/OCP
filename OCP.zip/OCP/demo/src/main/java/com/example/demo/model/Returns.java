package com.example.demo.model;

public class Returns {

	private String orderId;
	
	private String siteCode;
	
	private String itemIndex;
	
	private String confirm;
	
	private String itemCondition;
	
	private String storeNo;
	
	private String isExchange;

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getSiteCode() {
		return siteCode;
	}

	public void setSiteCode(String siteCode) {
		this.siteCode = siteCode;
	}

	public String getItemIndex() {
		return itemIndex;
	}

	public void setItemIndex(String itemIndex) {
		this.itemIndex = itemIndex;
	}

	public String getConfirm() {
		return confirm;
	}

	public void setConfirm(String confirm) {
		this.confirm = confirm;
	}

	public String getItemCondition() {
		return itemCondition;
	}

	public void setItemCondition(String itemCondition) {
		this.itemCondition = itemCondition;
	}

	public String getStoreNo() {
		return storeNo;
	}

	public void setStoreNo(String storeNo) {
		this.storeNo = storeNo;
	}

	public String getIsExchange() {
		return isExchange;
	}

	public void setIsExchange(String isExchange) {
		this.isExchange = isExchange;
	}

	public Returns() {
		super();
		this.orderId = orderId;
		this.siteCode = siteCode;
		this.itemIndex = itemIndex;
		this.confirm = confirm;
		this.itemCondition = itemCondition;
		this.storeNo = storeNo;
		this.isExchange = isExchange;
	}

	@Override
	public String toString() {
		return "Returns [orderId=" + orderId + ", siteCode=" + siteCode + ", itemIndex=" + itemIndex + ", confirm="
				+ confirm + ", itemCondition=" + itemCondition + ", storeNo=" + storeNo + ", isExchange=" + isExchange
				+ "]";
	}

	
}
