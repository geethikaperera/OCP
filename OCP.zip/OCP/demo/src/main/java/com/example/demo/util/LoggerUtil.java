package com.example.demo.util;

import com.fasterxml.jackson.databind.ObjectMapper;

public class LoggerUtil {

	public static String convertToString(Object object) {
		try {
			ObjectMapper objectMapper = new ObjectMapper();
			return objectMapper.writeValueAsString(object);
		} catch (Exception e) {
			return null;
		}
	}
}
