package com.example.demo.service;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpEntity;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.springframework.stereotype.Service;

import com.example.demo.model.ItemsObject;
import com.example.demo.model.Order;
import com.example.demo.model.OrderSiteCode;
import com.example.demo.model.ReturnEnum;
import com.example.demo.model.Returns;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;

@Service
public class ReadCSVService {

	public void read() throws IOException {	
		List<Order> orderList = getDetails("D:\\orders.csv");
		Returns returns = new Returns();

			for(Order order:orderList) {
			
				returns.setOrderId(order.getOrderId());
				
				List<OrderSiteCode> orderSiteCodeList = new ArrayList<>();
				OrderSiteCode orderSiteCode = new OrderSiteCode();
				orderSiteCode.setSiteCode(ReturnEnum.siteCode.getEnum());
				orderSiteCodeList.add(orderSiteCode);	
				returns.setOrders(orderSiteCodeList);
				
				List<ItemsObject> itemList = new ArrayList<>();
				ItemsObject items = new ItemsObject();
				items.setItemIndex(order.getItemIndex());
				items.setConfirm(ReturnEnum.confirm.getEnum());
				items.setItemCondition(ReturnEnum.itemCondition.getEnum());
				items.setStoreNo(ReturnEnum.storeNo.getEnum());
				items.setIsExchange(order.getIsExchange());
				itemList.add(items);
				returns.setItems(itemList);
						
		        try (CloseableHttpClient httpclient = HttpClients.createDefault()) {
		            HttpPost httpPost = new HttpPost("https://stg.stevemadden.com/services/wmi/shipment/return.do");
		            httpPost.setHeader("Accept", "application/json");
		            httpPost.setHeader("Content-type", "application/json");
		            	
					ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
					String json = ow.writeValueAsString(returns);
			        
//					String json = "\r\n"
//							+ "    {\r\n"
//							+ "        \"OrderId\": \"SMUS#3711533\",\r\n"
//							+ "        \"Order\": {\r\n"
//							+ "            \"SiteCode\": \"SM\"\r\n"
//							+ "        },\r\n"
//							+ "        \"Items\": [\r\n"
//							+ "            {\r\n"
//							+ "                \"ItemIndex\": 13508235,\r\n"
//							+ "                \"Confirm\": \"Y\",\r\n"
//							+ "                \"ItemCondition\": \"NEW\",\r\n"
//							+ "                \"StoreNo\": 906,\r\n"
//							+ "                \"IsExchange\": \"Y\"\r\n"
//							+ "            }\r\n"
//							+ "        ]\r\n"
//							+ "    }";
					
		            StringEntity stringEntity = new StringEntity(json);
		            System.out.println(json);
		            httpPost.setEntity(stringEntity);

		            System.out.println("Executing request " + httpPost.getRequestLine());

		            // Create a custom response handler
		            ResponseHandler < String > responseHandler = response -> {
		                int status = response.getStatusLine().getStatusCode();
		                if (status >= 200 && status < 300) {
		                    HttpEntity entity = response.getEntity();
		                    return entity != null ? EntityUtils.toString(entity) : null;
		                } else {
		                    throw new ClientProtocolException("Unexpected response status: " + status);
		                }
		            };
		            String responseBody = httpclient.execute(httpPost, responseHandler);
		            System.out.println("----------------------------------------");
		            System.out.println(responseBody);
		        }
			}
	}
	
	private static List<Order> getDetails(String file) throws IOException {
		List<Order> orderList = new ArrayList<>();
		Path pathToFile = Paths.get(file);
		try(BufferedReader br = Files.newBufferedReader(pathToFile)){
			String row = br.readLine();
			while(row!=null) {
				String [] attributes = row.split(",");
				Order order = getOneOrder(attributes);
				orderList.add(order);
				row = br.readLine();
			}
		}
		catch (IOException e) {
			e.printStackTrace();
		}
	return orderList;
	}

	private static Order getOneOrder(String[] attributes) {
		String OrderId = attributes[0];
		String siteCode = attributes[1];
		String itemIndex = attributes[2];
		String confirm = attributes[3];
		String itemCondition = attributes[4];
		String StoreNo = attributes[5];
		String isExchange = attributes[6];	
		
		Order order = new Order(OrderId, siteCode, itemIndex, confirm, itemCondition, StoreNo, isExchange);
		return order;
	}

}

