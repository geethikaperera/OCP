package com.example.demo.service;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.model.Order;
import com.example.demo.model.Returns;

@Service
public class ReadCSVService {

	public void read()  throws IOException {	
		List<Order> orderList = getDetails("D:\\orders.csv");
		for(Order order:orderList) {
			System.out.println(order);	
			OrdersToReturn(order);
		}
	}
	
	private static List<Order> getDetails(String file) throws IOException {
		List<Order>  orderList = new ArrayList<>();
		Path pathToFile = Paths.get(file);
		try(BufferedReader br = Files.newBufferedReader(pathToFile)){
			String row = br.readLine();
			while(row!=null) {
				String [] attributes = row.split(",");
				Order order = getOneOrder(attributes);
				orderList.add(order);
				row = br.readLine();
			}
		}
		catch (IOException e) {
			e.printStackTrace();
		}
		return orderList;
	}

	private static Order getOneOrder(String[] attributes) {
		String custId = attributes[0];
		String siteCode = attributes[1];
		String itemIndex = attributes[2];
		String confirm = attributes[3];
		String ItemCondition = attributes[4];
		String StoreNo = attributes[5];
		String isExchange = attributes[6];	
		
		Order order = new Order(custId, itemIndex, ItemCondition);
		return order;
	}
	
	private Returns OrdersToReturn (Order order) {
		Returns returns = new Returns();
		returns.setOrderId(order.getOrderId());
		returns.setSiteCode(order.getSiteCode());
		returns.setItemIndex(order.getItemIndex());
		returns.setConfirm(order.getConfirm());
		returns.setItemCondition(order.getItemCondition());
		returns.setStoreNo(order.getStoreno());
		returns.setIsExchange(order.getIsExchange());
		
		return returns;		
	}
}

