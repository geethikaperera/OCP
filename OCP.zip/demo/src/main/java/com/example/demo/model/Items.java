package com.example.demo.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Items {

	@JsonProperty("ItemIndex")
	private String itemIndex;
	
	@JsonProperty("Confirm")
	private String confirm;
	
	@JsonProperty("ItemCondition")
	private String itemCondition;
	
	@JsonProperty("StoreNo")
	private String storeNo;
	
	@JsonProperty("IsExchange")
	private String isExchange;

	public String getItemIndex() {
		return itemIndex;
	}

	public void setItemIndex(String itemIndex) {
		this.itemIndex = itemIndex;
	}

	public String getConfirm() {
		return confirm;
	}

	public void setConfirm(String confirm) {
		this.confirm = confirm;
	}

	public String getItemCondition() {
		return itemCondition;
	}

	public void setItemCondition(String itemCondition) {
		this.itemCondition = itemCondition;
	}

	public String getStoreNo() {
		return storeNo;
	}

	public void setStoreNo(String storeNo) {
		this.storeNo = storeNo;
	}

	public String getIsExchange() {
		return isExchange;
	}

	public void setIsExchange(String isExchange) {
		this.isExchange = isExchange;
	}
	
}
