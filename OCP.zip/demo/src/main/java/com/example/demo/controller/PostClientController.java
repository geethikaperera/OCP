package com.example.demo.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.example.demo.service.ReadCSVService;

@Controller
public class PostClientController {

	private static final Logger LOGGER = LoggerFactory.getLogger(PostClientController.class);
	
	@Autowired
	private ReadCSVService readCSVService;
	
	@PostMapping("/upload")
	public void read(@RequestParam("file") MultipartFile file) throws Exception{
		readCSVService.read();
	}

	@PostMapping("/post-order")
	public void postOrder()throws Exception{
		
//		String requestString = LoggerUtil.convertToString(jsonReq);
//		LOGGER.info("postOrderRequest : Order={}", requestString);
		
//		readCSVService.postUser();
		
		
//		String responseString = LoggerUtil.convertToString(response);
//		LOGGER.info("postOrderResponse : Order={}", responseString);
	    //return ResponseEntity.ok().body(new Response());
	}
}
