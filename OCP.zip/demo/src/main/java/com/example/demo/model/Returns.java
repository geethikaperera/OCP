package com.example.demo.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Returns {

	@JsonProperty("OrderId")
	private String orderId;
	
	@JsonProperty("Order")
	private OrderSiteCode orders;

	private List<Items> Items;

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public OrderSiteCode getOrders() {
		return orders;
	}

	public void setOrders(OrderSiteCode orders) {
		this.orders = orders;
	}

	@JsonProperty("Items")
	public List<Items> getItems() {
		return Items;
	}

	public void setItems(List<Items> items) {
		Items = items;
	}

}
