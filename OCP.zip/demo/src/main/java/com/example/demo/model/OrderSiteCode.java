package com.example.demo.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class OrderSiteCode {


	private String SiteCode;

	@JsonProperty("SiteCode")
	public String getSiteCode() {
		return SiteCode;
	}

	public void setSiteCode(String siteCode) {
		SiteCode = siteCode;
	}
	
}
