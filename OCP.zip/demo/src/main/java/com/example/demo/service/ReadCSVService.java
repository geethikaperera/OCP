package com.example.demo.service;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpEntity;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.springframework.stereotype.Service;

import com.example.demo.model.Items;
import com.example.demo.model.Order;
import com.example.demo.model.OrderSiteCode;
import com.example.demo.model.ReturnEnum;
import com.example.demo.model.Returns;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;

@Service
public class ReadCSVService {

	public void read() throws IOException {	
		List<Order> orderList = getDetails("D:\\Shipment code\\Book.csv");
		Returns returns = new Returns();
			
			//passing order to returns
			for(Order order:orderList) {
			
				returns.setOrderId(order.getOrderId());

				OrderSiteCode orderSiteCode = new OrderSiteCode();
				orderSiteCode.setSiteCode(ReturnEnum.siteCode.getEnum());
				returns.setOrders(orderSiteCode);
				
				List<Items> itemList = new ArrayList<>();
				Items items = new Items();
				items.setItemIndex(order.getItemIndex());
				items.setConfirm(ReturnEnum.confirm.getEnum());
				items.setItemCondition(ReturnEnum.itemCondition.getEnum());
				items.setStoreNo(ReturnEnum.storeNo.getEnum());
				items.setIsExchange(order.getIsExchange());
				itemList.add(items);
				returns.setItems(itemList);
						
		        try (CloseableHttpClient httpclient = HttpClients.createDefault()) {
		            HttpPost httpPost = new HttpPost("https://stg.stevemadden.com/services/wmi/shipment/return.do");
		            //HttpPost  httpPost = new HttpPost("https://smworld.stevemadden.com/services/wmi/shipment/return.do");
		            httpPost.setHeader("Accept", "application/json");
		            httpPost.setHeader("Content-type", "application/json");
		            
		            //returns object to json conversion
					ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
					String json = ow.writeValueAsString(returns);

		            StringEntity stringEntity = new StringEntity(json);
		            System.out.println(json);
		            httpPost.setEntity(stringEntity);

		            System.out.println("Executing request " + httpPost.getRequestLine());

		            // Create a custom response handler
		            ResponseHandler < String > responseHandler = response -> {
		                int status = response.getStatusLine().getStatusCode();
		                if (status >= 200 && status < 300) {
		                    HttpEntity entity = response.getEntity();
		                    return entity != null ? EntityUtils.toString(entity) : null;
		                } else {
		                    throw new ClientProtocolException("Unexpected response status: " + status);
		                }
		            };
		            String responseBody = httpclient.execute(httpPost, responseHandler);
		            System.out.println(responseBody);
		            System.out.println("----------------------------------------");
		        }
			}
	}
	
	private static List<Order> getDetails(String file) throws IOException {
		List<Order> orderList = new ArrayList<>();
		Path pathToFile = Paths.get(file);
		try(BufferedReader br = Files.newBufferedReader(pathToFile)){
			String row = br.readLine();
			while(row!=null) {
				String [] attributes = row.split(",");
				Order order = getOneOrder(attributes);
				orderList.add(order);
				row = br.readLine();
			}
		}
		catch (IOException e) {
			e.printStackTrace();
		}
	return orderList;
	}

	private static Order getOneOrder(String[] attributes) {
		String OrderId = attributes[0];
		String itemIndex = attributes[1];
		String isExchange = attributes[2];	
		
		Order order = new Order(OrderId, itemIndex, isExchange);
		return order;
	}

}

